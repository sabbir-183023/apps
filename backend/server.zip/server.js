import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import mongoose from "mongoose";
import dataRoutes from "./routes/data.js";
import authRoutes from "./routes/auth.js";

dotenv.config();

const PORT = process.env.PORT;
const CONNECTION_URL = process.env.MONGODB_URI;
// const dbName = process.env.MONGODB_DB_NAME;



mongoose.connect(CONNECTION_URL);

const app = express();
app.use(express.json());
app.use(
  cors({
    origin: ["http://localhost:5173"],
    credentials: true,
  })
);

app.use("/api/data", dataRoutes);
app.use("/api/auth", authRoutes);

app.listen(PORT, () => {
  console.log(`${"app is running on port " + PORT}`);
});
